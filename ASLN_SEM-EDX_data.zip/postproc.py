import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import scipy.special
plt.rcParams["figure.figsize"] = (10,8)

#----------------------------------
#| Proportion de Cu en % d'atomes |
#----------------------------------
pieces = ['support entrainement',
            'roue remontage centre',
            'roue remontage droite',
            'roue minutes',
            'roue de champ',
            'couvercle',
            'disque entrainement',
            'potence',
            'roue entrainement',
            'roue heures',
            'roue rencontre',
            'platine arrière',
            'platine avant',
            'fausse platine',
            'décoration rochet',
            'porte-suspension g.',
            'porte-suspension d.',
            'décoration verge',
            'pont minuterie',
            'tambour']

parties = [['disque','cylindre'],
            ['cylindre'],
            ['cylindre'],
            ['disque','pignon','arbre'],
            ['serge','assiette'],
            ['côté signatures'],
            ['côté pignon'],
            ['base','proche palier'],
            ['pignon','planche','dent replantée\n longue','dent replantée\n courte'],
            ['carré canon','planche'],
            ['serge'],
            ['filet vis porte susp','bouchon'],
            ['filet vis pont d.','face cadran','bouchon intérieur','bouchon extérieur','croix','rivet gauche'],
            ['proche grand trou'],
            ['dos'],
            ['base'],
            ['base'],
            ['partie limée','palier verge','tige bouchon'],
            ['partie haute','cylindre central'],
            ['fond']]

Cu = [77.53,76.48,
        64.42,
        66.63,
        68.36,67.84,68.49,
        69.94,76.94,
        67.46,
        66.87,
        66.63,57.7,
        77.1,71.01,68.27,67.26,
        77.48,77.9,
        68.26,
        65.21,80.84,
        66.61,67.93,80.21,83.82,67.94,81.85,
        63.02,
        64.12,
        66.57,
        67.76,
        69.15,60.88,95.58,
        65.92,58.23,
        75.96]

incert = [[282.4,0.78,66.93,1.7],[135.54,1.16,34.08,2.42],
                [158.49,1,71.62,1.51],
                [188.46,1,77.2,1.63],
                [144.85,0.92,56.17,1.51],[55.52,1.73,20.88,2.88],[269.47,0.82,102.04,1.37],
                [111.18,1.17,39.09,1.86],[100.34,1.38,24.59,2.91],
                [631.42,0.68,249.11,1.11],
                [222.22,0.89,90.05,1.44],
                [225.12,0.97,92.22,1.56],[161.65,1.06,96.96,1.38],
                [275.87,0.8,67.03,1.7],[253.04,0.91,84.52,1.63],[150.89,1.06,57.36,1.75],[135.46,1.14,53.94,1.85],
                [164.11,1.05,39.03,2.27],[179.34,0.85,41.6,1.86],
                [67.55,1.21,25.71,2.05],
                [44.23,2.37,19.3,3.94],[107.56,1.39,20.84,3.37],
                [390.23,0.73,160.01,1.18],[211.52,1,81.7,1.65],[251.82,0.91,50.82,2.17],[175.68,1.1,27.74,3.03],[238.4,0.94,92.04,1.56],[234.36,0.94,42.52,2.37],
                [100.5,1.45,48.23,2.13],
                [189.3,1.06,86.64,1.62],
                [230.02,0.96,94.5,1.54],
                [242.5,0.93,94.36,1.54],
                [217.94,0.98,79.52,1.69],[208.92,1.01,109.8,1.42],[166.54,1.13,6.3,8.42],
                [201.54,1.02,85.26,1.6],[231.3,0.95,135.74,1.26],
                [222.46,0.97,57.6,2.03]]

#état des zones mesurées
#0 = pas oxydé, 1 = un peu d'oxydation, 2 = oxydation moyenne, 3 = beaucoup d'oxydation
oxyd = [2,1,
        1,
        2,
        2,1,1,
        2,3,
        2,
        2,
        1,1,
        0,3,1,1,
        2,2,
        2,
        0,2,
        0,2,2,2,2,2,
        2,
        2,
        1,
        1,
        1,3,2,
        2,1,
        2]

#présence de dorure
#0 = partie non dorée, 1 = partie dorée, 2 = prévue d'être dorée (pignon min.), 3 = a été doré (roue rencontre)
dorure = [0,0,
            0,
            0,
            2,2,2,
            1,0,
            1,
            0,
            1,0,
            0,1,1,1,
            0,0,
            3,
            1,1,
            1,1,1,1,1,1,
            1,
            1,
            1,
            1,
            1,0,0,
            1,0,
            0]

#présence d'étain
#0 = pas d'étain discernable, 2 = étain en faible quantité, 1 = étain en quantité moyenne
etain = [1,1,
            0,
            0,
            2,0,0,
            2,1,
            0,
            0,
            2,2,
            0,0,0,0,
            0,0,
            0,
            0,1,
            2,2,1,0,2,0,
            0,
            2,
            0,
            0,
            2,0,1,
            2,0,
            2]

noms_ = []
for i in range(len(pieces)):
    for j in range(len(parties[i])):
        noms_.append(pieces[i]+' - '+parties[i][j])

bornes_inf_ = []
bornes_sup_ = []
for k in range(len(noms_)):
    dCu = (1.222*incert[k][2]/((incert[k][0]+1.222*incert[k][2])**2))*0.01*incert[k][0]*incert[k][1] + (incert[k][0]/((incert[k][0]+1.222*incert[k][2])**2))*0.01*incert[k][2]*incert[k][3]
    bornes_inf_.append(Cu[k]-1.96*100*dCu)
    bornes_sup_.append(Cu[k]+1.96*100*dCu)

indices = np.argsort(Cu)
noms = []
bornes_inf = []
bornes_sup = []
for k in range(len(Cu)):
    noms.append(noms_[indices[k]])
    bornes_inf.append(bornes_inf_[indices[k]])
    bornes_sup.append(bornes_sup_[indices[k]])

couleurs = []
for k in range(len(Cu)):
    if oxyd[indices[k]]==0:
        couleurs.append('green')
    elif oxyd[indices[k]]==1:
        couleurs.append('yellow')
    elif oxyd[indices[k]]==2:
        couleurs.append('orange')
    elif oxyd[indices[k]]==3:
        couleurs.append('red')

couleurs2 = ['black','red','orange','yellow']

data_dict = {}
data_dict['pieces'] = noms
data_dict['lower'] = bornes_inf
data_dict['upper'] = bornes_sup
dataset = pd.DataFrame(data_dict)

Cu = np.sort(Cu)

#Concentration de Cu
plt.plot([100-28 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='blue',linewidth=5)
plt.plot([100-33.3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='red',linewidth=5)
for lower,upper,y in zip(dataset['lower'],dataset['upper'],range(len(dataset))):
    plt.plot((lower,upper),(y,y),'ro-',color=couleurs[y],linewidth=3,markersize=10)
plt.yticks(range(len(dataset)),list(dataset['pieces']),fontsize=13)
plt.plot(Cu,[k for k in range(len(Cu))],'bs',markersize=10)
plt.grid()
plt.xlim([50,100])
moy_1 = sum(Cu[6:26])/20
moy_2 = sum(Cu[26:33])/7
moy_3 = sum(Cu[33:37])/4
plt.plot([moy_1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_1+3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_1-3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_2+1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_2-1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_3+2.2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_3-2.2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')

#Présence de dorure
for lower,upper,y in zip(dataset['lower'],dataset['upper'],range(len(dataset))):
    plt.plot((lower,upper),(y,y),'ro-',color='grey',linewidth=2,markersize=5)
plt.yticks(range(len(dataset)),list(dataset['pieces']),fontsize=13)
for k in range(len(Cu)):
    plt.plot(Cu[k],k,'bs',color=couleurs2[dorure[indices[k]]],markersize=10)
plt.grid()
plt.xlim([50,100])
moy_1 = sum(Cu[6:26])/20
moy_2 = sum(Cu[26:33])/7
moy_3 = sum(Cu[33:37])/4
plt.plot([moy_1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_1+3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_1-3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_2+1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_2-1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_3+2.2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_3-2.2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')

#Présence d'étain
for lower,upper,y in zip(dataset['lower'],dataset['upper'],range(len(dataset))):
    plt.plot((lower,upper),(y,y),'ro-',color='grey',linewidth=2,markersize=5)
plt.yticks(range(len(dataset)),list(dataset['pieces']),fontsize=13)
for k in range(len(Cu)):
    plt.plot(Cu[k],k,'bs',color=couleurs2[etain[indices[k]]],markersize=10)
plt.grid()
plt.xlim([50,100])
moy_1 = sum(Cu[6:26])/20
moy_2 = sum(Cu[26:33])/7
moy_3 = sum(Cu[33:37])/4
plt.plot([moy_1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_1+3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_1-3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_2+1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_2-1 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_3 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'--',color='black')
plt.plot([moy_3+2.2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')
plt.plot([moy_3-2.2 for k in range(len(Cu)+2)],[k-1 for k in range(len(Cu)+2)],'-',color='black')

#Fonction de répartition
plt.plot(Cu[6:26],[k/20+0.5/20 for k in range(20)],'bs')
sigma = np.sqrt(sum([(Cu[k]-moy_1)**2 for k in range(6,26)])/20)
print(sigma)
plt.plot([0.1*k for k in range(620,731)],[(1+scipy.special.erf((0.1*k-moy_1)/np.sqrt(2)/sigma))*0.5 for k in range(620,731)])
plt.grid()
plt.ylim([-0.2,1.2])
plt.xlim([62,73])
plt.xlabel('[Cu] (%)')
plt.ylabel('$\Phi$')
plt.legend(['Mesures','Fonction de répartition extrapolée'])
#écart-type moyen du premier intervalle
sigma = sum([0.5*(bornes_sup[k]-bornes_inf[k]) for k in range(6,26)])/20/1.96
print(sigma)

#----------------------------------
#| Proportion de Hg en % d'atomes |
#----------------------------------
pieces2 = ['couronne',
            'couvercle',
            'décoration rochet',
            'porte suspension d.',
            'potence inf.',
            'platine arrière']

parties2 = [['dent'],
            ['côté signature'],
            ['flanc sup.'],
            ['flanc sup.'],
            ['flanc carré','base'],
            ['bouchon','proche bouchon']]

Hg = [6.04,
        6.12,
        8.31,
        8.02,
        6.69,5.5,
        11.69,6.12]

incert2 = [[175.26,1.06,9.96,9.7],
            [181.26,1.14,10.45,10.57],
            [178.66,1.12,14.33,7.83],
            [207.02,0.67,15.96,4.89],
            [115.44,1.05,7.33,8.34],[85.78,1.57,4.42,15.85],
            [49.55,2.27,5.8,10.55],[48.55,2.27,2.8,19.59]]

noms2 = []
for i in range(len(pieces2)):
    for j in range(len(parties2[i])):
        noms2.append(pieces2[i]+'\n '+parties2[i][j])

bornes_inf2 = []
bornes_sup2 = []
for k in range(len(noms2)):
    dHg = (1.131*incert[k][2]/((incert[k][0]+1.131*incert[k][2])**2))*0.01*incert[k][0]*incert[k][1] + (incert[k][0]/((incert[k][0]+1.131*incert[k][2])**2))*0.01*incert[k][2]*incert[k][3]
    bornes_inf2.append(Hg[k]-1.96*100*dHg)
    bornes_sup2.append(Hg[k]+1.96*100*dHg)

data_dict2 = {}
data_dict2['pieces'] = noms2
data_dict2['lower'] = bornes_inf2
data_dict2['upper'] = bornes_sup2
dataset2 = pd.DataFrame(data_dict2)

for lower,upper,y in zip(dataset2['lower'],dataset2['upper'],range(len(dataset2))):
    plt.plot((lower,upper),(y,y),'ro-',color='blue',linewidth=3,markersize=10)
plt.yticks(range(len(dataset2)),list(dataset2['pieces']))
plt.plot(Hg,[k for k in range(len(Hg))],'bs',linewidth=3,markersize=10)

moy = sum(Hg)/len(Hg)
plt.plot([moy for k in range(len(Hg)+2)],[k-1 for k in range(len(Hg)+2)],'--',color='black')
plt.grid()