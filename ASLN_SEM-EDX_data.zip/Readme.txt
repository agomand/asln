------------------------------------------------------------
 Informations sur les données des analyses spectroscopiques
------------------------------------------------------------
(English below)

Les données brutes sont réparties entre plusieurs dossiers,
selon le métal analysé.
Un fichier de post-traitement en langage Python est fourni.
C'est ce fichier qui a été utilisé pour tracer les graphes
présents dans le mémoire de l'étude.
Il peut être ouvert avec une distribution Python classique
(version 3), e.g. Anaconda / Spyder.
Le programme est structuré de la manière suivante :

- lignes 1-5 : import des librairies utiles
  --> impératif avant d'exécuter une autre partie du code

- lignes 7-225 : calcul des concentrations de laiton et de
                 leur tracé
  --> exécuter uniquement ces lignes pour visualiser les
      concentrations des laitons

- lignes 227-246 : visualisation des pièces dorées
  --> exécuter d'abord les lignes 7-203, puis 227-246 pour
      visualiser les pièces dorées en fonction de [Cu]

- lignes 248-267 : visualisation des pièces qui contiennent
                   de l'étain
  --> exécuter d'abord les lignes 7-203, puis 248-267 pour
      visualiser la présence d'étain en fonction de [Cu]

- lignes 269-282 : fonction de répartition et écarts-types
                   associés au laiton de type 1 (~67%)
  --> exécuter d'abord les lignes 7-203, puis 269-282 pour
      visualiser la répartition des [Cu] du laiton de type 1

- lignes 284-340 : calcul des concentrations de mercure et
                   de leur tracé
  --> exécuter uniquement ces lignes pour visualiser les
      concentrations des mercure dans la dorure



---------------------------------------------------------
 Information on the data from the spectroscopic analyses
---------------------------------------------------------

The raw data are divided into several folders, depending
on the metal being analysed.
A post-processing file in Python is provided. This is the
file that was used to draw the graphs in the memorandum.
It can be opened with a standard Python distribution (v.3),
e.g. Anaconda / Spyder.
The program is structured as follows:

- lines 1-5: import of useful libraries
  --> mandatory before executing another part of the code

- lines 7-225: calculation and plot of brass concentrations
  --> run only these lines to view the brass concentrations
      of the brasses

- lines 227-246: plot of the gilded parts
  --> run first lines 7-203, then lines 227-246 to show the
      gilded parts as a function of [Cu]

- lines 248-267: plot of the parts that contain some tin
  --> run first lines 7-203, then lines 248-267 to show the
      parts that contain some tin as a function of [Cu]

- lines 269-282: plot of distribution function and standard
                 deviations of the brass of type 1 (~67%)
  --> run first lines 7-203, then lines 269-282 to show the
      distribution function of the brasses of type 1

- lines 284-340: calculation and plot of mercury concentrations
  --> run only these lines to view the mercury concentrations
      in the gilded parts